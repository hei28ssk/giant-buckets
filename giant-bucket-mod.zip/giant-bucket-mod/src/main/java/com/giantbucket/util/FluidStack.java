package com.giantbucket.util;

import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * Represents a stored fluid and its amount (in "buckets", where 1 = one vanilla bucket worth).
 * Stored inside ItemStack NBT under the key "GiantBucketFluid".
 */
public class FluidStack {

    public static final int MAX_BUCKETS = 100;
    public static final String NBT_KEY = "GiantBucketFluid";
    private static final String FLUID_ID_KEY = "FluidId";
    private static final String AMOUNT_KEY = "Amount";

    private Fluid fluid;
    private int amount; // number of vanilla bucket units stored

    public FluidStack(Fluid fluid, int amount) {
        this.fluid = fluid;
        this.amount = amount;
    }

    public static FluidStack empty() {
        return new FluidStack(Fluids.EMPTY, 0);
    }

    public boolean isEmpty() {
        return fluid == Fluids.EMPTY || amount <= 0;
    }

    public Fluid getFluid() {
        return fluid;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
        if (this.amount <= 0) {
            this.fluid = Fluids.EMPTY;
            this.amount = 0;
        }
    }

    /**
     * Returns true if this stack can accept the given fluid.
     * An empty stack accepts any fluid. A non-empty stack only accepts the same fluid.
     */
    public boolean canAccept(Fluid incoming) {
        if (incoming == Fluids.EMPTY) return false;
        if (isEmpty()) return true;
        // Compare by still-fluid equivalence so water == flowing_water, etc.
        return getStillFluid(fluid) == getStillFluid(incoming);
    }

    /**
     * Try to add one bucket of the given fluid. Returns true on success.
     */
    public boolean addBucket(Fluid incoming) {
        if (!canAccept(incoming)) return false;
        if (amount >= MAX_BUCKETS) return false;
        if (isEmpty()) {
            this.fluid = getStillFluid(incoming);
        }
        this.amount++;
        return true;
    }

    /**
     * Try to remove one bucket. Returns the fluid that was removed, or EMPTY if nothing to remove.
     */
    public Fluid removeBucket() {
        if (isEmpty()) return Fluids.EMPTY;
        Fluid removed = fluid;
        amount--;
        if (amount <= 0) {
            fluid = Fluids.EMPTY;
            amount = 0;
        }
        return removed;
    }

    // ---- NBT serialization ----

    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        if (!isEmpty()) {
            nbt.putString(FLUID_ID_KEY, Registries.FLUID.getId(fluid).toString());
            nbt.putInt(AMOUNT_KEY, amount);
        }
        return nbt;
    }

    public static FluidStack fromNbt(NbtCompound nbt) {
        if (nbt == null || !nbt.contains(FLUID_ID_KEY)) return empty();
        String idStr = nbt.getString(FLUID_ID_KEY);
        Identifier id = Identifier.tryParse(idStr);
        if (id == null) return empty();
        Fluid fluid = Registries.FLUID.get(id);
        if (fluid == null || fluid == Fluids.EMPTY) return empty();
        int amount = nbt.getInt(AMOUNT_KEY);
        return new FluidStack(fluid, amount);
    }

    // ---- Helpers ----

    /**
     * Normalise flowing variants to their still form so water == flowing_water, etc.
     * Works for vanilla and should work for most mod fluids that follow the same convention.
     */
    public static Fluid getStillFluid(Fluid fluid) {
        if (fluid == Fluids.FLOWING_WATER) return Fluids.WATER;
        if (fluid == Fluids.FLOWING_LAVA) return Fluids.LAVA;
        // For modded fluids we rely on the fluid's own still form if it exposes one,
        // otherwise just compare directly.
        return fluid;
    }

    public String getDisplayName() {
        if (isEmpty()) return "Empty";
        Identifier id = Registries.FLUID.getId(fluid);
        // Turn "minecraft:water" -> "Water", "mod:crude_oil" -> "Crude Oil"
        String path = id.getPath().replace('_', ' ');
        String[] words = path.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (!w.isEmpty()) {
                sb.append(Character.toUpperCase(w.charAt(0)));
                sb.append(w.substring(1));
                sb.append(' ');
            }
        }
        return sb.toString().trim();
    }

    @Override
    public String toString() {
        return "FluidStack{" + getDisplayName() + " x" + amount + "}";
    }
}

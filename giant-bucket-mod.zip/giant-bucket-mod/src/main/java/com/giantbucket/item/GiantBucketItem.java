package com.giantbucket.item;

import com.giantbucket.util.FluidStack;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidFillable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class GiantBucketItem extends Item {

    public static final int MAX_BUCKETS = FluidStack.MAX_BUCKETS;

    public GiantBucketItem(Settings settings) {
        super(settings);
    }

    // -----------------------------------------------------------------------
    // NBT helpers
    // -----------------------------------------------------------------------

    public static FluidStack getFluidStack(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        if (nbt == null || !nbt.contains(FluidStack.NBT_KEY)) return FluidStack.empty();
        return FluidStack.fromNbt(nbt.getCompound(FluidStack.NBT_KEY));
    }

    public static void setFluidStack(ItemStack stack, FluidStack fs) {
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.put(FluidStack.NBT_KEY, fs.toNbt());
    }

    // -----------------------------------------------------------------------
    // Right-click behaviour
    // -----------------------------------------------------------------------

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack giantStack = player.getStackInHand(hand);
        FluidStack stored = getFluidStack(giantStack);

        // Raycast to find what we're pointing at
        HitResult hit = raycast(world, player, stored.isEmpty()
                ? RaycastContext.FluidHandling.SOURCE_ONLY   // picking up: target fluid sources
                : RaycastContext.FluidHandling.NONE);        // placing: target solid blocks

        if (hit.getType() == HitResult.Type.MISS) {
            return TypedActionResult.pass(giantStack);
        }

        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) hit;
            BlockPos pos = blockHit.getBlockPos();

            // --- FILL: pick up fluid from world ---
            if (stored.isEmpty() || !stored.isEmpty() && stored.getAmount() < MAX_BUCKETS) {
                BlockState state = world.getBlockState(pos);
                Fluid fluid = state.getFluidState().getFluid();

                if (fluid != Fluids.EMPTY && fluid instanceof FlowableFluid flowable
                        && flowable.isStill(world.getFluidState(pos))) {

                    if (stored.canAccept(fluid)) {
                        if (!world.isClient) {
                            stored.addBucket(fluid);
                            setFluidStack(giantStack, stored);
                            world.removeBlock(pos, false);
                            world.emitGameEvent(player, GameEvent.FLUID_PICKUP, pos);
                            playFillSound(world, player, fluid, pos);
                            updateItemName(giantStack, stored);
                        }
                        player.incrementStat(Stats.USED.getOrCreateStat(this));
                        return TypedActionResult.success(giantStack, world.isClient());
                    }
                }
            }

            // --- PLACE: pour fluid into world ---
            if (!stored.isEmpty()) {
                Direction face = blockHit.getSide();
                BlockPos placePos = pos.offset(face);
                BlockState placeState = world.getBlockState(placePos);
                Block placeBlock = placeState.getBlock();

                // Allow placing into FluidFillable blocks (like cauldrons) or into air/replaceable
                boolean canPlace = placeState.isAir() || placeState.isLiquid()
                        || (placeBlock instanceof FluidFillable fillable
                        && fillable.canFillWithFluid(player, world, placePos, placeState, stored.getFluid()));

                if (canPlace && world.canPlayerModifyAt(player, placePos)) {
                    if (!world.isClient) {
                        Fluid toPlace = stored.getFluid();
                        if (placeBlock instanceof FluidFillable fillable) {
                            fillable.tryFillWithFluid(world, placePos, placeState, ((FlowableFluid) toPlace).getStill(false));
                        } else {
                            world.setBlockState(placePos,
                                    ((FlowableFluid) toPlace).getStill(false).getDefaultState().getBlockState(), 3);
                        }
                        stored.removeBucket();
                        setFluidStack(giantStack, stored);
                        world.emitGameEvent(player, GameEvent.FLUID_PLACE, placePos);
                        playEmptySound(world, player, toPlace, placePos);
                        updateItemName(giantStack, stored);
                    }
                    player.incrementStat(Stats.USED.getOrCreateStat(this));
                    return TypedActionResult.success(giantStack, world.isClient());
                }
            }
        }

        return TypedActionResult.pass(giantStack);
    }

    // -----------------------------------------------------------------------
    // Interact with other bucket items in inventory
    // (Shift+right-click on a held bucket to add it to the giant bucket,
    //  or use /give and the fill command — see below)
    // -----------------------------------------------------------------------

    /**
     * Called when this item is used on another entity (not used here)
     * but we also hook into the crafting-style "merge bucket" interaction
     * via the static helpers below, called from the item's use context.
     */

    /**
     * If the player is holding a filled vanilla bucket (water/lava/etc.) in their
     * off-hand and the giant bucket in main hand, absorb it.
     * This is checked in use() implicitly; we expose helpers for external calls.
     */
    public static boolean tryAbsorbBucket(ItemStack giantStack, ItemStack bucketStack, PlayerEntity player) {
        if (!(bucketStack.getItem() instanceof BucketItem bucketItem)) return false;

        Fluid fluid = getBucketFluid(bucketItem);
        if (fluid == Fluids.EMPTY) return false;

        FluidStack stored = getFluidStack(giantStack);
        if (!stored.canAccept(fluid)) return false;
        if (stored.getAmount() >= MAX_BUCKETS) return false;

        stored.addBucket(fluid);
        setFluidStack(giantStack, stored);
        updateItemName(giantStack, stored);

        // Replace the filled bucket with an empty one
        if (!player.isCreative()) {
            bucketStack.decrement(1);
            player.getInventory().offerOrDrop(new ItemStack(Items.BUCKET));
        }
        return true;
    }

    /**
     * Extract one bucket from the giant bucket into the player's inventory.
     * Returns true on success.
     */
    public static boolean tryExtractBucket(ItemStack giantStack, PlayerEntity player) {
        FluidStack stored = getFluidStack(giantStack);
        if (stored.isEmpty()) return false;

        Fluid fluid = stored.getFluid();
        Item bucketItem = fluid.getBucketItem();
        if (bucketItem == Items.AIR) return false;

        if (!player.isCreative()) {
            stored.removeBucket();
            setFluidStack(giantStack, stored);
            updateItemName(giantStack, stored);
        }

        ItemStack filledBucket = new ItemStack(bucketItem);
        player.getInventory().offerOrDrop(filledBucket);
        return true;
    }

    // -----------------------------------------------------------------------
    // Name / tooltip helpers
    // -----------------------------------------------------------------------

    public static void updateItemName(ItemStack stack, FluidStack fs) {
        if (fs.isEmpty()) {
            stack.setCustomName(Text.literal("Giant Bucket")
                    .formatted(Formatting.AQUA, Formatting.BOLD));
        } else {
            stack.setCustomName(
                    Text.literal("Giant Bucket")
                            .formatted(Formatting.AQUA, Formatting.BOLD)
                            .append(Text.literal(" [" + fs.getDisplayName() + " " + fs.getAmount() + "/" + MAX_BUCKETS + "]")
                                    .formatted(Formatting.YELLOW)));
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, net.minecraft.item.tooltip.TooltipType context) {
        FluidStack fs = getFluidStack(stack);
        if (fs.isEmpty()) {
            tooltip.add(Text.literal("Empty").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Capacity: " + MAX_BUCKETS + " buckets").formatted(Formatting.DARK_GRAY));
        } else {
            tooltip.add(Text.literal("Fluid: ").formatted(Formatting.GRAY)
                    .append(Text.literal(fs.getDisplayName()).formatted(Formatting.WHITE)));
            tooltip.add(Text.literal("Stored: ").formatted(Formatting.GRAY)
                    .append(Text.literal(fs.getAmount() + " / " + MAX_BUCKETS + " buckets").formatted(Formatting.YELLOW)));
        }
        tooltip.add(Text.literal("Right-click: fill/pour in world").formatted(Formatting.DARK_GRAY, Formatting.ITALIC));
        tooltip.add(Text.literal("Sneak+R-click: extract one bucket").formatted(Formatting.DARK_GRAY, Formatting.ITALIC));
    }

    // -----------------------------------------------------------------------
    // Sound helpers
    // -----------------------------------------------------------------------

    private void playFillSound(World world, PlayerEntity player, Fluid fluid, BlockPos pos) {
        SoundEvent sound = fluid.isIn(FluidTags.LAVA)
                ? SoundEvents.ITEM_BUCKET_FILL_LAVA
                : SoundEvents.ITEM_BUCKET_FILL;
        world.playSound(null, pos, sound, SoundCategory.PLAYERS, 1.0f, 1.0f);
    }

    private void playEmptySound(World world, PlayerEntity player, Fluid fluid, BlockPos pos) {
        SoundEvent sound = fluid.isIn(FluidTags.LAVA)
                ? SoundEvents.ITEM_BUCKET_EMPTY_LAVA
                : SoundEvents.ITEM_BUCKET_EMPTY;
        world.playSound(null, pos, sound, SoundCategory.PLAYERS, 1.0f, 1.0f);
    }

    // -----------------------------------------------------------------------
    // Utility: get the fluid from a BucketItem via reflection/accessor
    // -----------------------------------------------------------------------

    private static Fluid getBucketFluid(BucketItem bucketItem) {
        // BucketItem.fluid is private — we use Fabric API accessor mixin (see BucketItemAccessor)
        // or fall back to checking the item identity for vanilla buckets.
        if (bucketItem == Items.WATER_BUCKET) return Fluids.WATER;
        if (bucketItem == Items.LAVA_BUCKET) return Fluids.LAVA;
        // For modded buckets, we use the accessor mixin
        if (bucketItem instanceof BucketItemFluidAccessible accessible) {
            return accessible.giantbucket_getFluid();
        }
        return Fluids.EMPTY;
    }

    // Marker interface implemented by the mixin
    public interface BucketItemFluidAccessible {
        Fluid giantbucket_getFluid();
    }
}

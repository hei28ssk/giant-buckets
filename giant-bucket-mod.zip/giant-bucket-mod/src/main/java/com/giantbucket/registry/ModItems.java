package com.giantbucket.registry;

import com.giantbucket.GiantBucketMod;
import com.giantbucket.item.GiantBucketItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItems {

    public static final GiantBucketItem GIANT_BUCKET = new GiantBucketItem(
            new Item.Settings()
                    .maxCount(1)          // never stack — each has independent fluid NBT
                    .maxDamage(0)
    );

    public static void register() {
        Registry.register(
                Registries.ITEM,
                Identifier.of(GiantBucketMod.MOD_ID, "giant_bucket"),
                GIANT_BUCKET
        );

        // Add to the "Tools" creative tab near other buckets
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            ItemStack stack = new ItemStack(GIANT_BUCKET);
            GiantBucketItem.updateItemName(stack, com.giantbucket.util.FluidStack.empty());
            entries.add(stack);
        });
    }
}

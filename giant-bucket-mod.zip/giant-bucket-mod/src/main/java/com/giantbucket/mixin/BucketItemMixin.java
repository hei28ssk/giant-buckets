package com.giantbucket.mixin;

import com.giantbucket.item.GiantBucketItem;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.BucketItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Exposes the private {@code fluid} field of {@link BucketItem} so GiantBucketItem
 * can read the fluid from ANY bucket item — vanilla or modded — without reflection.
 *
 * Modded buckets that extend BucketItem (the standard Fabric pattern) will
 * automatically work through this mixin.
 */
@Mixin(BucketItem.class)
public abstract class BucketItemMixin implements GiantBucketItem.BucketItemFluidAccessible {

    @Shadow
    private Fluid fluid;

    @Override
    public Fluid giantbucket_getFluid() {
        return this.fluid;
    }
}

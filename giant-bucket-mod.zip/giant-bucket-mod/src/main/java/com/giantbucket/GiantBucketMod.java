package com.giantbucket;

import com.giantbucket.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GiantBucketMod implements ModInitializer {

    public static final String MOD_ID = "giantbucket";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.register();
        LOGGER.info("Giant Bucket mod loaded!");
    }
}
